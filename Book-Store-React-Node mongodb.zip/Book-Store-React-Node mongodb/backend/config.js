import "dotenv/config";

export const PORT = 5555;

export const mongoDBURL ="mongodb://0.0.0.0:27017/bookstore";